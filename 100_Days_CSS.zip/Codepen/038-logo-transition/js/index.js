// CLICK IT
$('.frame').bind('click', function() {
	$('.white').toggleClass('normal big');
	$('.purple').toggleClass('small normal');
});