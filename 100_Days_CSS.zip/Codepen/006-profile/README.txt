A Pen created at CodePen.io. You can find this one at http://codepen.io/roydigerhund/pen/OMreoV.

 This pen is part of my 100 Days CSS Challenge, view all pens under http://100dayscss.com