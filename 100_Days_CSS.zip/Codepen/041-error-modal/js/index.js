$('.button').bind('click', function() {
	$('.modal').addClass('hide');
});